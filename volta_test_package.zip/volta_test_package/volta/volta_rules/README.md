# Volta_Rules
## Steps to Create Udev Rules for device bindings :

### 1. For binding sensors - 
```
$ rosrun volta_rules sensor_read.py  
```
### 2. For updating udev rules - 
```
$ rosrun volta_rules create_udev_rules
```
