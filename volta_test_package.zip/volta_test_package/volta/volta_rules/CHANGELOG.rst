^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package volta_rules
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2021-06-23)
------------------
* First Release
* Noetic-devel initial commit.
* Contributors: toship-botsync
