^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package volta_navigation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2021-06-23)
------------------
* First Release
* Added stage rviz config.
* Noetic-devel initial commit.
* Contributors: toship-botsync
